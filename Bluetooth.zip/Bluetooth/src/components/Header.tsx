import { Button } from "@/components/ui/button";
import { Menu, X, Package, Home, Search, Phone, LogIn } from "lucide-react";
import { useState } from "react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-primary text-primary-foreground shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <Package className="h-8 w-8" />
            <span className="text-xl font-bold">TrackPro</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="flex items-center space-x-1 hover:text-primary-foreground/80 transition-colors">
              <Home className="h-4 w-4" />
              <span>Home</span>
            </a>
            <a href="#track" className="flex items-center space-x-1 hover:text-primary-foreground/80 transition-colors">
              <Search className="h-4 w-4" />
              <span>Track</span>
            </a>
            <a href="#contact" className="flex items-center space-x-1 hover:text-primary-foreground/80 transition-colors">
              <Phone className="h-4 w-4" />
              <span>Contact</span>
            </a>
          </nav>

          {/* Desktop Login Button */}
          <div className="hidden md:flex">
            <Button variant="outline" size="sm" className="border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground hover:text-primary">
              <LogIn className="h-4 w-4 mr-2" />
              Admin Login
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-primary-foreground hover:bg-primary-foreground/10"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-primary-foreground/20 py-4">
            <nav className="flex flex-col space-y-4">
              <a href="#home" className="flex items-center space-x-2 hover:text-primary-foreground/80 transition-colors">
                <Home className="h-4 w-4" />
                <span>Home</span>
              </a>
              <a href="#track" className="flex items-center space-x-2 hover:text-primary-foreground/80 transition-colors">
                <Search className="h-4 w-4" />
                <span>Track</span>
              </a>
              <a href="#contact" className="flex items-center space-x-2 hover:text-primary-foreground/80 transition-colors">
                <Phone className="h-4 w-4" />
                <span>Contact</span>
              </a>
              <Button variant="outline" size="sm" className="self-start border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground hover:text-primary">
                <LogIn className="h-4 w-4 mr-2" />
                Admin Login
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
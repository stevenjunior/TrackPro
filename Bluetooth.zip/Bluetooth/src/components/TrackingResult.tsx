import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Circle, MapPin, Calendar, Package, Truck, Home } from "lucide-react";

interface TrackingEvent {
  date: string;
  time: string;
  location: string;
  status: string;
  description: string;
}

interface TrackingResultProps {
  trackingNumber: string;
  status: "in-transit" | "delivered" | "pending" | "exception";
  currentStep: number;
  events: TrackingEvent[];
  estimatedDelivery?: string;
}

const TrackingResult = ({ 
  trackingNumber, 
  status, 
  currentStep, 
  events, 
  estimatedDelivery 
}: TrackingResultProps) => {
  const steps = [
    { label: "Order Placed", icon: Package },
    { label: "Shipped", icon: Truck },
    { label: "In Transit", icon: MapPin },
    { label: "Delivered", icon: Home }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "delivered": return "success";
      case "in-transit": return "default";
      case "pending": return "warning";
      case "exception": return "destructive";
      default: return "secondary";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "delivered": return "Delivered";
      case "in-transit": return "In Transit";
      case "pending": return "Pending";
      case "exception": return "Exception";
      default: return "Unknown";
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Status Overview */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle className="text-xl">Tracking: {trackingNumber}</CardTitle>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant={getStatusColor(status)} className="text-sm">
                  {getStatusText(status)}
                </Badge>
                {estimatedDelivery && (
                  <span className="text-sm text-muted-foreground">
                    Est. delivery: {estimatedDelivery}
                  </span>
                )}
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Progress Bar */}
          <div className="relative">
            <div className="flex justify-between items-center">
              {steps.map((step, index) => {
                const Icon = step.icon;
                const isCompleted = index < currentStep;
                const isCurrent = index === currentStep;
                
                return (
                  <div key={index} className="flex flex-col items-center relative z-10">
                    <div className={`
                      w-10 h-10 rounded-full border-2 flex items-center justify-center
                      ${isCompleted 
                        ? 'bg-success border-success text-success-foreground' 
                        : isCurrent 
                        ? 'bg-primary border-primary text-primary-foreground' 
                        : 'bg-background border-muted-foreground/30 text-muted-foreground'
                      }
                    `}>
                      {isCompleted ? (
                        <CheckCircle className="h-5 w-5" />
                      ) : (
                        <Icon className="h-5 w-5" />
                      )}
                    </div>
                    <span className={`
                      text-xs mt-2 text-center font-medium
                      ${isCompleted || isCurrent ? 'text-foreground' : 'text-muted-foreground'}
                    `}>
                      {step.label}
                    </span>
                  </div>
                );
              })}
            </div>
            
            {/* Progress Line */}
            <div className="absolute top-5 left-5 right-5 h-0.5 bg-muted -z-0">
              <div 
                className="h-full bg-success transition-all duration-500"
                style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Tracking History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {events.map((event, index) => (
              <div key={index} className="flex gap-4 pb-4 border-b border-border last:border-b-0 last:pb-0">
                <div className="flex-shrink-0">
                  <div className="w-3 h-3 bg-primary rounded-full mt-1.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
                    <div>
                      <p className="font-medium text-foreground">{event.status}</p>
                      <p className="text-sm text-muted-foreground">{event.description}</p>
                    </div>
                    <div className="text-sm text-muted-foreground text-right">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        <span>{event.location}</span>
                      </div>
                      <div>{event.date} {event.time}</div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TrackingResult;
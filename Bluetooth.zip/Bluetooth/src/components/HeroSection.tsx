import TrackingForm from "./TrackingForm";
import { TrendingUp, Globe, Shield } from "lucide-react";

interface HeroSectionProps {
  onTrack: (trackingNumber: string) => void;
  isLoading?: boolean;
}

const HeroSection = ({ onTrack, isLoading }: HeroSectionProps) => {
  return (
    <section className="py-16 lg:py-24">
      <div className="container mx-auto px-4 text-center">
        {/* Main Heading */}
        <div className="max-w-4xl mx-auto mb-12">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6">
            Professional Package
            <span className="text-primary block mt-2">Tracking System</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Track your packages with precision and confidence. Get real-time updates 
            from major carriers worldwide in one convenient location.
          </p>
        </div>

        {/* Tracking Form */}
        <div className="mb-16">
          <TrackingForm onTrack={onTrack} isLoading={isLoading} />
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="flex flex-col items-center p-6 bg-card rounded-xl border border-border">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
              <Globe className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-2">220+</h3>
            <p className="text-muted-foreground">Countries & Regions</p>
          </div>

          <div className="flex flex-col items-center p-6 bg-card rounded-xl border border-border">
            <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4">
              <TrendingUp className="h-6 w-6 text-accent" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-2">99.9%</h3>
            <p className="text-muted-foreground">Tracking Accuracy</p>
          </div>

          <div className="flex flex-col items-center p-6 bg-card rounded-xl border border-border">
            <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mb-4">
              <Shield className="h-6 w-6 text-success" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-2">24/7</h3>
            <p className="text-muted-foreground">Real-time Updates</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { useState } from "react";

interface TrackingFormProps {
  onTrack: (trackingNumber: string) => void;
  isLoading?: boolean;
}

const TrackingForm = ({ onTrack, isLoading = false }: TrackingFormProps) => {
  const [trackingNumber, setTrackingNumber] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (trackingNumber.trim()) {
      onTrack(trackingNumber.trim());
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Input
            type="text"
            placeholder="Enter your tracking number..."
            value={trackingNumber}
            onChange={(e) => setTrackingNumber(e.target.value)}
            className="h-12 text-base border-2 border-border focus:border-primary rounded-lg"
            disabled={isLoading}
          />
        </div>
        <Button
          type="submit"
          variant="accent"
          size="lg"
          disabled={!trackingNumber.trim() || isLoading}
          className="sm:min-w-[120px]"
        >
          <Search className="h-5 w-5 mr-2" />
          {isLoading ? "Tracking..." : "Track"}
        </Button>
      </form>
      
      <div className="mt-4 text-center">
        <p className="text-sm text-muted-foreground">
          Supports tracking from major carriers worldwide
        </p>
      </div>
    </div>
  );
};

export default TrackingForm;
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import TrackingResult from "@/components/TrackingResult";
import ErrorMessage from "@/components/ErrorMessage";
import Footer from "@/components/Footer";
import TrackingForm from "@/components/TrackingForm";
import { Phone, Mail, MapPin } from "lucide-react";

const Index = () => {
  const [trackingNumber, setTrackingNumber] = useState<string>("");
  const [trackingData, setTrackingData] = useState<any>(null);
  const [error, setError] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);

  const handleTrack = async (number: string) => {
    setIsLoading(true);
    setError("");
    setTrackingData(null);
    
    try {
      // Fetch parcel data from Supabase
      const { data: parcelData, error: parcelError } = await supabase
        .from('Parcels')
        .select('*')
        .eq('id', number)
        .single();

      if (parcelError || !parcelData) {
        setError("Tracking number not found. Please check your tracking number and try again.");
        setIsLoading(false);
        return;
      }

      // Fetch tracking events for this parcel
      const { data: eventsData, error: eventsError } = await supabase
        .from('tracking_events')
        .select('*')
        .eq('tracking_number', number)
        .order('event_date', { ascending: true })
        .order('event_time', { ascending: true });

      if (eventsError) {
        console.error('Error fetching events:', eventsError);
      }

      // Transform data to match the existing format
      const events = eventsData?.map(event => ({
        date: event.event_date,
        time: event.event_time,
        location: event.location,
        status: event.status,
        description: event.description
      })) || [];

      // Calculate current step based on status
      let currentStep = 0;
      let status = 'pending';
      
      if (parcelData.Status) {
        const statusLower = parcelData.Status.toLowerCase().trim();
        if (statusLower.includes('received') || statusLower.includes('accepted')) {
          currentStep = 1;
          status = 'pending';
        } else if (statusLower.includes('shipped')) {
          currentStep = 2;
          status = 'shipped';
        } else if (statusLower.includes('transit')) {
          currentStep = 2;
          status = 'in-transit';
        } else if (statusLower.includes('delivered')) {
          currentStep = 3;
          status = 'delivered';
        }
      }

      setTrackingData({
        trackingNumber: number,
        status,
        currentStep,
        events,
        estimatedDelivery: "Estimated delivery will be calculated"
      });
      setTrackingNumber(number);
    } catch (error) {
      console.error('Error fetching tracking data:', error);
      setError("An error occurred while fetching tracking data. Please try again.");
    }
    
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Home Section */}
        <section id="home">
          <HeroSection onTrack={handleTrack} isLoading={isLoading} />
        </section>
        
        {/* Track Section */}
        <section id="track" className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Track Your Package
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Enter your tracking number to get real-time updates on your shipment status
              </p>
            </div>
            
            <div className="max-w-2xl mx-auto mb-8">
              <TrackingForm onTrack={handleTrack} isLoading={isLoading} />
            </div>
            
            {error && (
              <div className="mb-8">
                <ErrorMessage message={error} />
              </div>
            )}
            
            {trackingData && (
              <div className="mb-8">
                <TrackingResult
                  trackingNumber={trackingData.trackingNumber}
                  status={trackingData.status}
                  currentStep={trackingData.currentStep}
                  events={trackingData.events}
                  estimatedDelivery={trackingData.estimatedDelivery}
                />
              </div>
            )}
          </div>
        </section>
        
        {/* Contact Section */}
        <section id="contact" className="py-16 bg-muted">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Contact Us
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Need help with your shipment? Get in touch with our support team
              </p>
            </div>
            
            <div className="max-w-4xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center p-6 bg-card rounded-lg border border-border">
                  <Phone className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Phone Support</h3>
                  <p className="text-muted-foreground text-sm mb-2">WhatsApp only</p>
                  <p className="font-medium">+1 (702) 493-2736</p>
                </div>
                
                <div className="text-center p-6 bg-card rounded-lg border border-border">
                  <Mail className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Email Support</h3>
                  <p className="text-muted-foreground text-sm mb-2">Get help via email</p>
                  <p className="font-medium">olanspoppi@gmail.com</p>
                </div>
                
                <div className="text-center p-6 bg-card rounded-lg border border-border">
                  <MapPin className="h-8 w-8 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Our Location</h3>
                  <p className="text-muted-foreground text-sm mb-2">Visit our office</p>
                  <p className="font-medium">3519 W 8th Street<br />Los Angeles, CA 90005<br />United States</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;

-- Add RLS policy for Parcels table to allow public read access
CREATE POLICY "Allow public read access to parcels" ON "Parcels"
FOR SELECT USING (true);
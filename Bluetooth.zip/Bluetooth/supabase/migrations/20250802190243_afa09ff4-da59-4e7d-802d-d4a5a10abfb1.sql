-- Insert sample tracking data into Parcels table
INSERT INTO "Parcels" (id, "Status", "Origin") VALUES 
('TN123456789', 'In Transit', 'New York, NY'),
('TN987654321', 'Delivered', 'Los Angeles, CA'),
('TN555444333', 'Shipped', 'Chicago, IL');

-- Create tracking_events table for timeline data
CREATE TABLE IF NOT EXISTS tracking_events (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  tracking_number text NOT NULL,
  event_date date NOT NULL,
  event_time time NOT NULL,
  location text NOT NULL,
  status text NOT NULL,
  description text NOT NULL,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on tracking_events
ALTER TABLE tracking_events ENABLE ROW LEVEL SECURITY;

-- Create policy to allow public read access (since this is a tracking service)
CREATE POLICY "Allow public read access to tracking events" ON tracking_events
FOR SELECT USING (true);

-- Insert sample tracking events
INSERT INTO tracking_events (tracking_number, event_date, event_time, location, status, description) VALUES 
('TN123456789', '2024-12-20', '14:30', 'New York, NY', 'Package Received', 'Package received at origin facility'),
('TN123456789', '2024-12-21', '08:15', 'Newark, NJ', 'In Transit', 'Package departed from sorting facility'),
('TN123456789', '2024-12-22', '12:45', 'Philadelphia, PA', 'In Transit', 'Package arrived at transit facility'),
('TN987654321', '2024-12-18', '09:00', 'Los Angeles, CA', 'Package Received', 'Package received at origin facility'),
('TN987654321', '2024-12-19', '15:30', 'Phoenix, AZ', 'In Transit', 'Package in transit to destination'),
('TN987654321', '2024-12-20', '11:15', 'Denver, CO', 'Delivered', 'Package delivered to recipient');
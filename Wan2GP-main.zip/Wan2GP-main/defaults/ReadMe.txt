Please dot not modify any file in this Folder.

If you want to change a property of a default model, copy the corrresponding model file in the ./finetunes folder and modify the properties you want to change in the new file.
If a property is not in the new file, it will be inherited automatically from the default file that matches the same name file.

For instance to hide a model:

{
	"model":
	{
		"visible": false
	}
}
